
Note:

1. 
cmd.do: Modelsim simulation script. For reference only.

2.
(1) In part 2 of "cmd.do", the "gw2a/prim_sim.v" file and the path should be modified or added by the Users. 
(2) "prim_sim.v" is a primitive library. Users need to add appropriate primitives according to the Device which be used.
(3) The "prim_sim.v" can be obtained from the Software installation directory. Its reference path is like "Gowin_v1.*\IDE\simlib"
(4) Users can also create simulation library files of Modelsim by themselves, and connect the work to the simulation library.
